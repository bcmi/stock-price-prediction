#begin LSTM
import numpy
import csv
import keras
from keras.models import Sequential
from keras.layers import LSTM, Dense, Activation, Dropout
from keras.utils import np_utils
from keras import regularizers
from keras.callbacks import EarlyStopping
import os 
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'


def preprocess(data):
    for i in range(len(data)-1,0,-1):
       data[i] = data[i] - data[i-1]
    data[0] = data[0] - data[0]
    normal(data)
    return data

def normal(data):
    m = numpy.mean(data)
    dmin,dmax = data.min(),data.max()
    return (data - m)/(dmax-dmin)

def get_model_data(data):
    A = data[:,1:]
    B = data[:,0:1]
    dataA = preprocess(A)
    datasetA = dataA[:int(len(dataA)/10)*10-20,:]
    datasetB = []
    for i in range(int(len(dataA)/10)-2):
        temp = 0
        for j in range(20):
            temp = temp + B[10*(i+1)+j] - B[10*(i+1)-1]
        datasetB.append(temp/20)
    datasetA = datasetA.reshape(int(len(datasetA)/10),50,1)
    datasetB = numpy.array(datasetB)
    train_size = int(len(datasetA)) 
    trainA,testA = datasetA[:train_size,:,:],datasetA[train_size:,:,:]
    trainB,testB = datasetB[:train_size,:],datasetB[train_size:,:]
    return trainA,trainB,testA,testB

def get_goal_data(test_data):
    dataA = test_data[:,1:]
    dataB = test_data[:,0:1]
    dataA = preprocess(dataA)
    datasetA = dataA[:,:]
    datasetA = datasetA.reshape(int(len(datasetA)/10),50,1)
    datasetB = []
    for i in range(int(len(datasetA))):
        datasetB.append(dataB[10*(i+1)-1])
    datasetB = numpy.array(datasetB)
    return datasetA,datasetB

def get_model(train_data,lstmFirstLayer,lstmSecondLayer):
    trainA,trainB,testA,testB = get_model_data(train_data)
    print("have dealed")
    model = Sequential()
    model.add(LSTM(lstmFirstLayer, input_shape=(trainA.shape[1], trainA.shape[2]),return_sequences=True))
    model.add(Dropout(0.15))
    model.add(LSTM(lstmSecondLayer,return_sequences=False))
    model.add(Dropout(0.15))
    model.add(Dense(units=1, kernel_regularizer=regularizers.l2(0.001),activation='tanh'))
    model.compile(loss="mae", optimizer="rmsprop")
    early_stopping = EarlyStopping(monitor='val_loss', patience=5)
    model.fit(trainA,trainB,batch_size=100,epochs=100,validation_data=(testA,testB),verbose=1,shuffle=False,callbacks=[early_stopping])
    hyperparams_name=str(lstmFirstLayer)+"-"+str(lstmSecondLayer)
    model.save(os.path.join('MODEL{}_cont.h5'.format(hyperparams_name)))
    return model

def predict(model):
    test_data = numpy.loadtxt("test_data.csv",delimiter= ',' , skiprows=1, usecols=(3,4,6,7,8,9))
    testX,testY = get_goal_data(test_data)
    result = model.predict(testX)
    result = result + testY
    return result

def output_result(result):
    id_price = ['caseid','midprice']
    out = open('result.csv','w', newline='')
    write = csv.writer(out,dialect='excel')
    write.writerow(id_price)
    for i in range(142,1000):
        temp = [i+1,result[i][0]]
        write.writerow(temp)

def main():
    Layer1 = 40
    Layer2 = 35
    name=str(Layer1)+"-"+str(Layer2)
    road = os.path.join('MODEL{}_cont.h5'.format(name))
    if (os.path.exists(road)):
        model = keras.models.load_model(road)
    else:
        train_data = numpy.loadtxt("train_data.csv",delimiter= ',' , skiprows=1, usecols=(3,4,6,7,8,9))
        model = get_model(train_data,Layer1,Layer2)
    result = predict(model)
    output_result(result)

main()